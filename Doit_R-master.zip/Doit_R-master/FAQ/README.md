FAQ
---
- [맥에서 불러들인 파일의 문자가 깨질 때](http://bit.ly/2mhQWeR)
- [맥에서 그래프의 한글이 깨질 때](http://bit.ly/2leaxfG)
- [맥에서 Java 설정하기](http://bit.ly/2mGlIhr)
- [맥에서 ggiraphExtra 패키지 설치 중 오류가 발생할 경우](http://bit.ly/2mH2Cb2)
- [ggChoropleth()로 만든 단계 구분도의 한글이 깨질 때](http://bit.ly/2mH335a)